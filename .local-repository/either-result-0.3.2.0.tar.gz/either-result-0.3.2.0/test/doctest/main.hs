{-# OPTIONS_GHC -F -pgmF doctest-discover #-}
